--- 
layout: post 
title: "Welcome to My Statistics Website" 
date: 2025-05-05 
categories: [Introduction] 
--- 
 
Welcome to my new website featuring my research in biostatistics, 
focusing on microbiome data analysis and smoothing splines. 
