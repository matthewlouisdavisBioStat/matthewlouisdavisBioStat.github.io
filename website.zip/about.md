--- 
layout: page 
title: About 
permalink: /about/ 
--- 
 
# About Me 
 
I am a biostatistician with expertise in statistical methods for microbiome data analysis, 
smoothing splines, and R package development. 
